--1 CREATE VIEW vw_ActiveSessions AS
SELECT s.session_id, c.name AS computer_name, cust.nickname, t.tariff_name, s.start_time, s.end_time
FROM Sessions s
JOIN Computers c ON s.computer_id = c.computer_id
JOIN Customers cust ON s.customer_id = cust.customer_id
JOIN Tariffs t ON s.tariff_id = t.tariff_id
WHERE s.status = N'Активна';

--2 
SELECT nickname, balance FROM Customers WHERE nickname = N'Neo';

--3 
UPDATE Computers SET status = N'Занят' WHERE computer_id = 2;

--4
SELECT computer_id, name, ip_address 
FROM Computers 
WHERE status = N'Свободен';

--5
UPDATE Customers 
SET balance = balance + 500.00 
WHERE nickname = N'Morpheus';

--6
SELECT c.name, c.status, c.ip_address 
FROM Computers c
JOIN Zones z ON c.zone_id = z.zone_id
WHERE z.zone_name = N'VIP комната';

--7
SELECT COUNT(*) AS total_customers 
FROM Customers;

--8
SELECT session_id, start_time, end_time, total_cost 
FROM Sessions 
WHERE status = N'Завершена'
ORDER BY total_cost DESC;