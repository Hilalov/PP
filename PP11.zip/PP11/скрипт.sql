USE ClubManagerDB;
GO

-- Удаление таблиц в обратном порядке связей, если они уже существовали
IF OBJECT_ID('dbo.Sessions', 'U') IS NOT NULL DROP TABLE dbo.Sessions;
IF OBJECT_ID('dbo.Tariffs', 'U') IS NOT NULL DROP TABLE dbo.Tariffs;
IF OBJECT_ID('dbo.Computers', 'U') IS NOT NULL DROP TABLE dbo.Computers;
IF OBJECT_ID('dbo.Zones', 'U') IS NOT NULL DROP TABLE dbo.Zones;
IF OBJECT_ID('dbo.Customers', 'U') IS NOT NULL DROP TABLE dbo.Customers;
IF OBJECT_ID('dbo.Employees', 'U') IS NOT NULL DROP TABLE dbo.Employees;
GO

-- 1.1. Таблица игровых зон
CREATE TABLE Zones (
    zone_id INT IDENTITY(1,1) PRIMARY KEY,
    zone_name NVARCHAR(100) NOT NULL,
    description NVARCHAR(255)
);

-- 1.2. Таблица компьютеров (Исправлено ограничение CHECK под статус 'Занят')
CREATE TABLE Computers (
    computer_id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(50) NOT NULL,
    ip_address NVARCHAR(50) NOT NULL,
    status NVARCHAR(50) NOT NULL CHECK (status IN (N'Свободен', N'Занят', N'Забронирован', N'Ремонт')),
    zone_id INT NOT NULL,
    FOREIGN KEY (zone_id) REFERENCES Zones(zone_id)
);

-- 1.3. Таблица клиентов
CREATE TABLE Customers (
    customer_id INT IDENTITY(1,1) PRIMARY KEY,
    nickname NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20) NOT NULL,
    balance DECIMAL(10,2) NOT NULL DEFAULT 0.00 CHECK (balance >= 0)
);

-- 1.4. Таблица тарифов
CREATE TABLE Tariffs (
    tariff_id INT IDENTITY(1,1) PRIMARY KEY,
    tariff_name NVARCHAR(100) NOT NULL,
    price_per_hour DECIMAL(10,2) NOT NULL CHECK (price_per_hour >= 0),
    duration_minutes INT NOT NULL CHECK (duration_minutes > 0),
    zone_id INT NOT NULL,
    FOREIGN KEY (zone_id) REFERENCES Zones(zone_id)
);

-- 1.5. Таблица игровых сессий
CREATE TABLE Sessions (
    session_id INT IDENTITY(1,1) PRIMARY KEY,
    start_time DATETIME NOT NULL,
    end_time DATETIME NOT NULL,
    status NVARCHAR(50) NOT NULL CHECK (status IN (N'Активна', N'Пауза', N'Завершена', N'Истекла')),
    total_cost DECIMAL(10,2) NOT NULL CHECK (total_cost >= 0),
    computer_id INT NOT NULL,
    customer_id INT NOT NULL,
    tariff_id INT NOT NULL,
    FOREIGN KEY (computer_id) REFERENCES Computers(computer_id),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (tariff_id) REFERENCES Tariffs(tariff_id)
);

-- 1.6. Таблица сотрудников
CREATE TABLE Employees (
    employee_id INT IDENTITY(1,1) PRIMARY KEY,
    full_name NVARCHAR(150) NOT NULL,
    position NVARCHAR(100) NOT NULL,
    phone NVARCHAR(20) NOT NULL
);
GO

-- 2.1. Заполнение зон
INSERT INTO Zones (zone_name, description) VALUES 
(N'Общий зал', N'Стандартные места'), 
(N'VIP комната', N'Топовые ПК');

-- 2.2. Заполнение компьютеров (Используются корректные статусы из CHECK)
INSERT INTO Computers (name, ip_address, status, zone_id) VALUES 
(N'ПК-01', '192.168.1.10', N'Свободен', 1), 
(N'ПК-02', '192.168.1.11', N'Занят', 1),
(N'VIP-01', '192.168.2.10', N'Ремонт', 2);

-- 2.3. Заполнение клиентов
INSERT INTO Customers (nickname, phone, balance) VALUES 
(N'Neo', '+79991112233', 350.00), 
(N'Morpheus', '+79994445566', 0.00);

-- 2.4. Заполнение тарифов
INSERT INTO Tariffs (tariff_name, price_per_hour, duration_minutes, zone_id) VALUES 
(N'Час общего зала', 100.00, 60, 1), 
(N'Пакет 3 часа VIP', 450.00, 180, 2);

-- 2.5. Заполнение игровых сессий (Исправлено на безошибочный ISO-формат дат YYYY-MM-DDTHH:MM:SS)
INSERT INTO Sessions (start_time, end_time, status, total_cost, computer_id, customer_id, tariff_id) VALUES 
('2026-06-25T10:00:00', '2026-06-25T13:00:00', N'Завершена', 300.00, 1, 1, 1),
('2026-06-25T12:00:00', '2026-06-25T15:00:00', N'Активна', 450.00, 2, 2, 2);

-- 2.6. Заполнение сотрудников
INSERT INTO Employees (full_name, position, phone) VALUES 
(N'Смирнов А.А.', N'Администратор', '+79110001122');
GO